class GameEndNotification {
    static ENDED_FLAG = 'ENDED_FLAG';
    static WIN = 'WIN';
    static PRESSED_ON_MINE = 'PRESSED_ON_MINE';
}
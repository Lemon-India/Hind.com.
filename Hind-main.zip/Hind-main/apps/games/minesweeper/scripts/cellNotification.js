class CellNotification {
  static FLAGGED = 'FLAGGED';
  static CELL_OPENED = 'OPENED';
  static MINE_OPENED = 'MINE_OPENED';
}